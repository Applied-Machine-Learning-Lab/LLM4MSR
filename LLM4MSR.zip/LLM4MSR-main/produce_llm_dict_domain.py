import pandas as pd
import torch
from tqdm import tqdm
import time
from transformers import AutoTokenizer, AutoModel
tokenizer = AutoTokenizer.from_pretrained("/chatglm/", trust_remote_code=True)
model = AutoModel.from_pretrained("/chatglm/", trust_remote_code=True).half().cuda()

data=pd.read_csv('/dataset/amazon_domain_prompt.csv')
llm_dict={}
start=time.time()
for i in tqdm(range(3)):
    seq=tokenizer(data.iloc[i,1],return_tensors="pt")
    seq=seq.to('cuda:0')
    gen_kwargs = {"max_length": 8192, "num_beams": 1, "do_sample": True, "top_p": 0.8,"temperature": 0.8, "logits_processor": None}
    outputs=model.generate(**seq, **gen_kwargs)
    print(outputs.shape)
    llm_dict[i]=outputs
end=time.time()
print(end-start)
torch.save(llm_dict,'/dataset/amazon_domain_dict.pt')
