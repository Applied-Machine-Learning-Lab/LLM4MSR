import numpy as np
import pandas as pd
import torch.utils.data

class amazon(torch.utils.data.Dataset):
    """
    KuaiSAR Dataset

    Reference:
        https://cseweb.ucsd.edu/~jmcauley/datasets/amazon_v2/
    """

    def __init__(self,mode):
        dataset_path_base='/dataset/'
        s1 = pd.read_csv(dataset_path_base+'amazon_scenario_1_'+mode+'.csv')
        s2 = pd.read_csv(dataset_path_base+'amazon_scenario_2_'+mode+'.csv')
        s3 = pd.read_csv(dataset_path_base+'amazon_scenario_3_'+mode+'.csv')
        data = pd.concat([s1, s2, s3])
        data=data.to_numpy()
        
        self.targets = data[:,2].astype(np.int64)
        self.items = data[:,:2].astype(np.int64)
        
        domain_id_1 = np.full((s1.shape[0],1),0)
        domain_id_2 = np.full((s2.shape[0],1),1)
        domain_id_3 = np.full((s3.shape[0],1),2)
        
        domain_id = np.concatenate([domain_id_1,domain_id_2,domain_id_3],0)
        self.items = np.concatenate([self.items,domain_id],1) 
        
        self.field_dims = np.ndarray(shape=(3,), dtype=np.int64)
        self.field_dims[0] = 8788+193304+6980
        self.field_dims[1] = 24753
        self.field_dims[2] = 3
        
            
    def __len__(self):
        return self.targets.shape[0]

    def __getitem__(self, index):
        return self.items[index], self.targets[index]

class amazon_domain(torch.utils.data.Dataset):

    def __init__(self,mode,name):
        dataset_path_base='/dataset/'
        data = pd.read_csv(dataset_path_base+'amazon_'+name+'_'+mode+'.csv')
        data=data.to_numpy()
        
        self.targets = data[:,2].astype(np.int64)
        self.items = data[:,:2].astype(np.int64)
        
        if name=='scenario_1':
            domain_id = np.full((data.shape[0],1),0)
        elif name=='scenario_2':
            domain_id = np.full((data.shape[0],1),1)
        else:
            domain_id = np.full((data.shape[0],1),2)
        
        self.items = np.concatenate([self.items,domain_id],1) 
        
        self.field_dims = np.ndarray(shape=(3,), dtype=np.int64)
        self.field_dims[0] = 8788+193304+6980
        self.field_dims[1] = 24753
        self.field_dims[2] = 3
        
            
    def __len__(self):
        return self.targets.shape[0]

    def __getitem__(self, index):
        return self.items[index], self.targets[index]
