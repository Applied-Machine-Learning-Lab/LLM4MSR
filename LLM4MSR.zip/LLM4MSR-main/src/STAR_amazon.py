import torch
from layer import FeaturesEmbedding,MultiLayerPerceptron,star_rest, star_core,dw_llm_3

class STAR(torch.nn.Module):
    """
    A pytorch implementation of STAR.
    Note!!!! tower[0] = bottom[0]
    """

    def __init__(self, categorical_field_dims, embed_dim, bottom_mlp_dims, tower_mlp_dims, task_num, dropout):#center + domain
        super().__init__()
        self.embedding = FeaturesEmbedding(categorical_field_dims, embed_dim)
        self.embed_dim = embed_dim
        self.embed_output_dim = (len(categorical_field_dims)) * embed_dim
        self.task_num = task_num
        self.aux = MultiLayerPerceptron(embed_dim,(32,32),dropout)
        self.rest = torch.nn.ModuleList([star_rest(tower_mlp_dims[i],dropout,i==len(tower_mlp_dims)-1) for i in range(len(tower_mlp_dims))])
        self.core = star_core(categorical_field_dims, embed_dim, bottom_mlp_dims, tower_mlp_dims, task_num)
            
        
    def forward(self, x):
        """
        :param 
        categorical_x: int64 tensor of size ``(batch_size, categorical_field_dims)``
        """
        categorical_emb = self.embedding(x)
        #numerical_emb = self.numerical_layer(numerical_x).unsqueeze(1)
        #numerical_emb = torch.tensor([]).to('cuda:0')
        embed_x = categorical_emb.view(-1, self.embed_output_dim)
        
        domain_embedding = embed_x[:,self.embed_output_dim-self.embed_dim:]
        
        fea = embed_x[:,:self.embed_output_dim-self.embed_dim]
        
        sa = self.aux(domain_embedding)#domain_id's embedding
        
        for j in range(1,1+self.task_num):
            present = fea
            for i in range(len(self.rest)):
                present = self.core(present,j,i)
                present = self.rest[i](present)
            if j==1:
                sm = present
            else:
                sm = torch.cat((sm,present),1)
        
        sa = sa.view(sa.shape[0])
        #sm = f.squeeze(1)
        
        results = [torch.sigmoid(sm[:,i]+sa) for i in range(self.task_num)]
        return results
        
class STAR_dw_llm_side_bottom_v2(torch.nn.Module):
    """
    A pytorch implementation of STAR.
    Note!!!! tower[0] = bottom[0]
    """

    def __init__(self, categorical_field_dims, embed_dim, bottom_mlp_dims, tower_mlp_dims, task_num, dropout):#center + domain
        super().__init__()
        self.embedding = FeaturesEmbedding(categorical_field_dims, embed_dim)
        self.embed_dim = embed_dim
        self.embed_output_dim = (len(categorical_field_dims)) * embed_dim
        self.task_num = task_num
        
        self.aux = MultiLayerPerceptron(embed_dim,(32,32),dropout)
        self.rest = torch.nn.ModuleList([star_rest(tower_mlp_dims[i],dropout,i==len(tower_mlp_dims)-1) for i in range(len(tower_mlp_dims))])
        self.core = star_core(categorical_field_dims, embed_dim, bottom_mlp_dims, tower_mlp_dims, task_num)
        self.dw = dw_llm_3(512, len(categorical_field_dims),inout_dim=[48,16,1],dropout=dropout)
        self.dw_bottom = dw_llm_3(512, len(categorical_field_dims),inout_dim=[48,48,48],dropout=dropout)
        self.llm_dict_domain = torch.load('/dataset/amazon_domain_dict.pt')
        self.llm_dict = torch.load('/dataset/amazon_user_dict.pt')
        self.alpha = torch.nn.Parameter(torch.tensor([[1.]]))
        
        
    def forward(self, x):
        """
        :param 
        categorical_x: int64 tensor of size ``(batch_size, categorical_field_dims)``
        """
        
        dom_id=x[:,2].tolist() #fetch domain_id
        dom_embedding=[self.llm_dict_domain.get(key) for key in dom_id]
        dom_embedding = torch.stack(dom_embedding)
        
        user_id=x[:,1].tolist() #fetch domain_id
        llm_embedding=[self.llm_dict.get(key) for key in user_id]
        llm_embedding = torch.stack(llm_embedding)
        
        categorical_emb = self.embedding(x)
        embed_x = categorical_emb.view(-1, self.embed_output_dim)
        
        domain_embedding = embed_x[:,self.embed_output_dim-self.embed_dim:]
        fea = embed_x[:,:self.embed_output_dim-self.embed_dim]
        
        
        dw_bottom_net_l1, dw_bottom_net_l2, dw_bottom_bias_l1, dw_bottom_bias_l2 = self.dw_bottom(llm_embedding.squeeze(1).squeeze(1))
        mid_bottom = torch.matmul(fea.view(fea.shape[0],1,fea.shape[1]), dw_bottom_net_l1)
        dw_bottom_out = mid_bottom + dw_bottom_bias_l1
        dw_bottom_out = torch.relu(dw_bottom_out)
        dw_bottom_out = torch.matmul(dw_bottom_out, dw_bottom_net_l2) + dw_bottom_bias_l2
        fea_process = dw_bottom_out.squeeze(1) #pay attention to shape!!!
        
        dw_net_l1, dw_net_l2, dw_bias_l1, dw_bias_l2 = self.dw(dom_embedding.squeeze(1).squeeze(1)) #[4096,1,4096]
        mid = torch.matmul(fea.view(fea.shape[0],1,fea.shape[1]), dw_net_l1)
        dw_out = mid + dw_bias_l1
        dw_out = torch.relu(dw_out)
        dw_out = torch.matmul(dw_out, dw_net_l2) + dw_bias_l2
        
        sa = self.aux(domain_embedding)#domain_id's embedding
        sa = sa.view(sa.shape[0])
        
        for j in range(1,1+self.task_num):
            present = fea_process
            for i in range(len(self.rest)):
                present = self.core(present,j,i)
                present = self.rest[i](present)
            if j==1:
                sm = present
            else:
                sm = torch.cat((sm,present),1)
        
        alpha = torch.sigmoid(self.alpha)
        sm = alpha*sm
        dw_out = (1-alpha)*dw_out
        dw_out = dw_out.reshape(dw_out.shape[0])
        results = [torch.sigmoid(sm[:,i]+sa+dw_out) for i in range(self.task_num)]
        return results
