import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

class FeaturesEmbedding(torch.nn.Module):

    def __init__(self, field_dims, embed_dim):
        super().__init__()
        self.embedding = torch.nn.Embedding(sum(field_dims), embed_dim)
        self.offsets = np.array((0, *np.cumsum(field_dims)[:-1]), dtype=np.int64)
        torch.nn.init.xavier_uniform_(self.embedding.weight.data)

    def forward(self, x):
        """
        :param x: int64 tensor of size ``(batch_size, num_fields)``
        """
        x = x + x.new_tensor(self.offsets).unsqueeze(0)
        return self.embedding(x)


class MultiLayerPerceptron(torch.nn.Module):

    def __init__(self, input_dim, embed_dims, dropout, output_layer=True):
        super().__init__()
        layers = list()
        for embed_dim in embed_dims:
            layers.append(torch.nn.Linear(input_dim, embed_dim))
            layers.append(torch.nn.BatchNorm1d(embed_dim))
            layers.append(torch.nn.ReLU())
            layers.append(torch.nn.Dropout(p=dropout))
            input_dim = embed_dim
        
        self.mlp = torch.nn.Sequential(*layers)
        if output_layer:
            self.mlp.add_module('output_l',torch.nn.Linear(input_dim, 1))

    def forward(self, x):
        """
        :param x: Float tensor of size ``(batch_size, embed_dim)``
        """
        return self.mlp(x)
    
        
class dw_llm_3(nn.Module):
    def __init__(self, embed_dim, len_field_dims, inout_dim, dropout=0.2):
        super().__init__()
        #self.d_embedding = FeaturesEmbedding([domain_num], embed_dim)
        self.dnn11 = nn.Linear(embed_dim, inout_dim[0] * inout_dim[1])
        self.dnn12 = nn.Linear(embed_dim, inout_dim[1] * inout_dim[2])
        self.bg11 = nn.Linear(embed_dim, inout_dim[1])
        self.bg12 = nn.Linear(embed_dim, inout_dim[2])
        #self.linear = nn.Linear(4096, 1024)
        #self.linear_2 = nn.Linear(1024, embed_dim)
        
        self.inout_dim = inout_dim
        self.embed_dim = embed_dim
        self.len_field_dims = len_field_dims
        layers = list()
        layers.append(torch.nn.Linear(4096, 1024))
        layers.append(torch.nn.BatchNorm1d(1024))
        layers.append(torch.nn.ReLU())
        #layers.append(torch.nn.Dropout(p=dropout))
        layers.append(torch.nn.Linear(1024, embed_dim))
        layers.append(torch.nn.BatchNorm1d(embed_dim))
        layers.append(torch.nn.ReLU())
        
        self.mlp = torch.nn.Sequential(*layers)
    def forward(self, x):
        #x = self.d_embedding(x).squeeze()
        # N*inout_dim[0]*inout_dim[1]
        x = self.mlp(x.float())
        
        net1 = self.dnn11(x).view(-1, self.inout_dim[0], self.inout_dim[1])
        net2 = self.dnn12(x).view(-1, self.inout_dim[1], self.inout_dim[2])
        # N*1*inout_dim[1]
        net1_bias = self.bg11(x).unsqueeze(1)
        net2_bias = self.bg12(x).unsqueeze(1)
        # N*im_num*(len_field_dims-1)*1
        return net1, net2, net1_bias, net2_bias
        
class star_rest(torch.nn.Module):

    def __init__(self, embed_dim, dropout, output_layer=False):
        super().__init__()
        layers = list()
        #for embed_dim in embed_dims:
        #layers.append(torch.nn.Linear(input_dim, embed_dim))
        layers.append(torch.nn.BatchNorm1d(embed_dim))
        layers.append(torch.nn.ReLU())
        layers.append(torch.nn.Dropout(p=dropout))
        
        self.mlp = torch.nn.Sequential(*layers)
        if output_layer:
            self.mlp.add_module('output_l',torch.nn.Linear(embed_dim, 1))

    def forward(self, x):
        """
        :param x: Float tensor of size ``(batch_size, embed_dim)``
        """
        return self.mlp(x)
    
class star_core(torch.nn.Module):

    def __init__(self, categorical_field_dims, embed_dim, bottom_mlp_dims, tower_mlp_dims, task_num):
        super().__init__()
        #for embed_dim in embed_dims:
        #layers.append(torch.nn.Linear(input_dim, embed_dim))
        self.domain_w = {}
        self.domain_b = {}
        self.star_weight = {}
        self.star_bias = {}
        #input_d = (len(categorical_field_dims)) * embed_dim #for ali-ccp
        input_d = (len(categorical_field_dims)-1) * embed_dim #for douban
        
        each_domain_w = []
        each_domain_b = []
        for k in range(len(bottom_mlp_dims)):
            w = torch.nn.Parameter(torch.Tensor(input_d,bottom_mlp_dims[k]),requires_grad=True)
            b = torch.nn.Parameter(torch.Tensor(tower_mlp_dims[k]),requires_grad=True)
            w = w.to('cuda:0')
            b = b.to('cuda:0')
            #w = w.to('cpu')
            #b = b.to('cpu')
            torch.nn.init.normal_(w,0,0.01)
            torch.nn.init.constant_(b,0.1)
            each_domain_w.append(w)
            each_domain_b.append(b)
            input_d = bottom_mlp_dims[k]
        self.domain_w[0] = each_domain_w #shared centered parameters
        self.domain_b[0] = each_domain_b
        
        for j in range(task_num):
            idx = j + 1
            each_domain_w = []
            each_domain_b = []
            overall_w = []
            overall_b = []
            for k in range(len(tower_mlp_dims)):
                w = torch.nn.Parameter(torch.Tensor(bottom_mlp_dims[k],tower_mlp_dims[k]),requires_grad=True)
                b = torch.nn.Parameter(torch.Tensor(tower_mlp_dims[k]),requires_grad=True)
                w = w.to('cuda:0')
                b = b.to('cuda:0')
                #w = w.to('cpu')
                #b = b.to('cpu')
                torch.nn.init.normal_(w,0,0.01)
                torch.nn.init.constant_(b,0.1)
                each_domain_w.append(w)
                each_domain_b.append(b)
                overall_w.append(torch.mm(self.domain_w[0][k],each_domain_w[k]))
                overall_b.append(self.domain_b[0][k]+each_domain_b[k])
                
            self.domain_w[idx] = each_domain_w
            self.domain_b[idx] = each_domain_b
            self.star_weight[idx] = overall_w
            self.star_bias[idx] = overall_b

    def forward(self, x,j,i):
        """
        :param x: Float tensor of size ``(batch_size, embed_dim)``
        """
        #print(self.domain_w[1][0])
        #print(self.domain_w[1][0].shape)
        #print(self.domain_b)
        #print(self.star_weight)
        #print(self.star_bias)
        y = torch.mm(x,self.star_weight[j][i]) + self.star_bias[j][i]
        return y