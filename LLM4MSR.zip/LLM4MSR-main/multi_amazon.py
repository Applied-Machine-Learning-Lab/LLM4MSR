import torch
import tqdm
from sklearn.metrics import roc_auc_score
from torch.utils.data import DataLoader
import numpy as np
import time
from collections import Counter
import os,sys
from src.amazon import amazon,amazon_domain
from src.STAR_amazon import STAR,STAR_dw_llm_side_bottom_v2

def get_dataset(name,mode,domain='default'):
    if domain=='default':
        return amazon(mode)
    else:
        return amazon_domain(mode, domain)

def get_model(name, categorical_field_dims, expert_num, embed_dim, dataset_name):
    """
    Hyperparameters are empirically determined, not opitmized.
    """
    
    numerical_num = 0
    task_num = 3
    
    if name == 'star':
        print("Model: STAR")
        return STAR(categorical_field_dims, embed_dim=embed_dim, bottom_mlp_dims=(64, 32, 16), tower_mlp_dims=(64, 32, 16), task_num=task_num, dropout=0.2)
    elif name == 'star_dw_llm_side_bottom_v2':
        print("Model: STAR_dw_llm_side_bottom_v2")
        return STAR_dw_llm_side_bottom_v2(categorical_field_dims, embed_dim=embed_dim, bottom_mlp_dims=(64, 32, 16), tower_mlp_dims=(64, 32, 16), task_num=task_num, dropout=0.2)       
    else:
        raise ValueError('unknown model name: ' + name)

class EarlyStopper(object):

    def __init__(self, num_trials, save_path):
        self.num_trials = num_trials
        self.trial_counter = 0
        self.best_accuracy = 0
        self.save_path = save_path

    def is_continuable(self, model, accuracy):
        if accuracy > self.best_accuracy:
            self.best_accuracy = accuracy
            self.trial_counter = 0
            #torch.save(model.state_dict(), self.save_path)
            torch.save(model, self.save_path)
            return True
        elif self.trial_counter + 1 < self.num_trials:
            self.trial_counter += 1
            return True
        else:
            return False

def train(model, optimizer, data_loader, criterion, device, log_interval=100):
    model.train()
    total_loss = 0
    loader = tqdm.tqdm(data_loader, smoothing=0, mininterval=1.0)
    for i, (categorical_fields, labels) in enumerate(loader):
        categorical_fields, labels = categorical_fields.to(device).long(), labels.to(device).long()
        y = model(categorical_fields)
        loss = 0
        
        category = categorical_fields[:,2].to('cpu')
        category = category.numpy()
        for j in range(np.max(category)+1):
            indexx = np.where(category==j)
            #print(indexx)
            if indexx==None:
                continue;
            position = y[j]
            result = position[indexx]
            loss += criterion(result, labels[indexx].float())
        
        model.zero_grad()
        loss.backward(retain_graph=True)
        optimizer.step()
        total_loss += loss.item()
        if (i + 1) % log_interval == 0:
            loader.set_postfix(loss=total_loss / log_interval)
            total_loss = 0

def test(model, data_loader, device):
    model.eval()
    labels_dict, predicts_dict= list(), list()
    with torch.no_grad():
        for categorical_fields, labels in tqdm.tqdm(data_loader, smoothing=0, mininterval=1.0):
            categorical_fields, labels = categorical_fields.to(device).long(), labels.to(device).long()
            y = model(categorical_fields)
            
            labels_dict.extend(labels.tolist())#true label
            pred = torch.zeros(categorical_fields.shape[0],dtype=torch.float32)
            
            category = categorical_fields[:,2].to('cpu')
            category = category.numpy()
            for j in range(np.max(category)+1):
                indexx = np.where(category==j)
                if indexx==None:
                    continue;
                position = y[j]
                position = position.to('cpu')
                pred[indexx]=position[indexx]
            predicts_dict.extend(pred.tolist())#simulated
    
    return roc_auc_score(labels_dict, predicts_dict)


def test_2(model, data_loader, device, indexx):
    model.eval()
    targets, predicts, loss = list(), list(), list()
    with torch.no_grad():
        for fields, target in tqdm.tqdm(data_loader, smoothing=0, mininterval=1.0):
            fields, target = fields.to(device).long(), target.to(device).long()
            y = model(fields)
            y=y[indexx-1]
            targets.extend(target.tolist())
            predicts.extend(y.tolist())
            loss.extend(torch.nn.functional.binary_cross_entropy(y,target.float(), reduction='none').tolist())
    return roc_auc_score(targets, predicts),np.array(loss).mean()

def main(dataset_name,
         dataset_path,
         task_num,
         expert_num,
         model_name,
         epoch,
         learning_rate,
         batch_size,
         embed_dim,
         weight_decay,
         device,
         save_dir,
         job):
    device = torch.device(device)
    
    address = f'{save_dir}/{model_name}/{dataset_name}_{model_name}_{learning_rate}.txt'
    file = open(address,'w')
    sys.stdout=file
    
    train_dataset = get_dataset(dataset_name,'train')
    val_dataset = get_dataset(dataset_name,'val')
    test_dataset = get_dataset(dataset_name,'test')
    
    train_data_loader = DataLoader(train_dataset, batch_size=batch_size, num_workers=2,shuffle = True)
    val_data_loader = DataLoader(val_dataset, batch_size=batch_size, num_workers=2)
    test_data_loader = DataLoader(test_dataset, batch_size=batch_size, num_workers=2)

    field_dims = train_dataset.field_dims 
    
    model = get_model(model_name, field_dims, expert_num, embed_dim, dataset_name).to(device)
    
    print(dataset_name)
    print(model_name)
    
    criterion = torch.nn.BCELoss()
    optimizer = torch.optim.Adam(params=model.parameters(), lr=learning_rate, weight_decay=weight_decay)
    save_path = f'{save_dir}/{dataset_name}_{model_name}_{learning_rate}.pt'
    
    early_stopper = EarlyStopper(num_trials=3, save_path=save_path)
    start = time.time()
    
    for epoch_i in range(epoch):
        train(model, optimizer, train_data_loader, criterion, device)
        auc = test(model, val_data_loader, device)
        print('epoch:', epoch_i, 'val: auc:', auc)
        if not early_stopper.is_continuable(model, auc):
            print(f'best auc: {early_stopper.best_accuracy}')
            break
    end = time.time()
    
    model = torch.load(save_path)
    
    test_dataset_1=get_dataset(dataset_name,'test',domain='scenario_1')
    test_dataset_2=get_dataset(dataset_name,'test',domain='scenario_2')
    test_dataset_3=get_dataset(dataset_name,'test',domain='scenario_3')
    test_data_loader_1 = DataLoader(test_dataset_1, batch_size=batch_size, num_workers=2)
    test_data_loader_2 = DataLoader(test_dataset_2, batch_size=batch_size, num_workers=2)
    test_data_loader_3 = DataLoader(test_dataset_3, batch_size=batch_size, num_workers=2)
    
    auc,loss = test_2(model, test_data_loader_1, device, indexx=1)
    print(f'test auc on domain 1: {auc}, loss: {loss}')
    auc,loss = test_2(model, test_data_loader_2, device, indexx=2)
    print(f'test auc on domain 2: {auc}, loss: {loss}')
    auc,loss = test_2(model, test_data_loader_3, device, indexx=3)
    print(f'test auc on domain 3: {auc}, loss: {loss}')
    print('running time = ',end - start)
    file.close()


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset_name', default='amazon', choices=['amazon','kuaisar_small','kuaisar_v2'])
    parser.add_argument('--dataset_path', default='/dataset/')
    parser.add_argument('--model_name', default='star_dw_llm_side_bottom_v2')
    parser.add_argument('--epoch', type=int, default=50)
    parser.add_argument('--task_num', type=int, default=3)
    parser.add_argument('--expert_num', type=int, default=6)
    parser.add_argument('--learning_rate', type=float, default=2e-3)
    parser.add_argument('--batch_size', type=int, default=1024)
    parser.add_argument('--embed_dim', type=int, default=16)
    parser.add_argument('--weight_decay', type=float, default=1e-5)
    parser.add_argument('--device', default='cuda:0')
    parser.add_argument('--save_dir', default='/ckpt/')
    parser.add_argument('--job', type=int, default=1)
    args = parser.parse_args()
    main(args.dataset_name,
         args.dataset_path,
         args.task_num,
         args.expert_num,
         args.model_name,
         args.epoch,
         args.learning_rate,
         args.batch_size,
         args.embed_dim,
         args.weight_decay,
         args.device,
         args.save_dir,
         args.job)